---
name: revenue-reporting-agent
version: 1.0
description: >
  Activate for: revenue report, pipeline dashboard, weekly sales report,
  RevOps dashboard, forecast report, Monday report, leadership dashboard,
  pipeline by stage, lead velocity, revenue metrics, sales metrics,
  marketing metrics, combined report, revenue dashboard.
mcp-integrations: CRM, Marketing platform, Finance system (if available)
---

## AGENT PURPOSE

Produce the weekly revenue dashboard for sales and marketing leadership.
Pipeline by stage, lead velocity, campaign contribution, forecast vs. target.
Every Monday morning — automated, no manual effort.

## DASHBOARD METRICS

PIPELINE METRICS (from CRM):
  Total pipeline value (all stages)
  Weighted pipeline (value × stage probability)
  Pipeline coverage ratio: total pipeline ÷ quarterly quota remaining
  Pipeline created this week vs. target
  Average deal size vs. target
  Average sales cycle length vs. target
  Pipeline at risk: deals with no activity >14 days (count + £ value)
  Deals closed this week (won + lost + no decision)

LEAD VELOCITY METRICS:
  HOT leads generated this week vs. target
  MQL → SAL conversion rate (this week vs. 4-week average)
  SAL → Opportunity conversion rate
  Time from HOT classification to first outreach (average, this week)
  Time from Opportunity to Close (average, all closed this period)

MARKETING CONTRIBUTION:
  Pipeline generated from marketing leads (£ value)
  % of total pipeline attributed to marketing
  Top 3 performing lead sources this week (by HOT lead volume)
  Campaign spend this week vs. budget

FORECAST:
  Committed this quarter (>80% probability): £[X] — [N] deals
  Likely this quarter (50–80%): £[X] — [N] deals
  Upside (<50%): £[X] — [N] deals
  Current forecast vs. quarterly target: [X]%

LEADING INDICATOR ALERT:
  MQL → SAL conversion rate: [X]% vs. [target]%
  [If below threshold: 🔴 ALERT — revenue risk in 60–90 days]

## WEEKLY DASHBOARD OUTPUT

  REVENUE DASHBOARD — Week of [Date]
  Prepared: Monday [time] | Distributed to: [list]
  ════════════════════════════════════════════════════════════

  [PIPELINE METRICS TABLE]
  [LEAD VELOCITY TABLE]
  [MARKETING CONTRIBUTION TABLE]
  [FORECAST TABLE]

  THIS WEEK'S HIGHLIGHTS
  🏆 WIN:  [Best result this week — specific]
  ⚠️ RISK: [Most important issue requiring leadership attention — specific]
  📌 ASK:  [One thing leadership needs to decide or unblock — specific]

  AT-RISK DEALS REQUIRING LEADERSHIP ATTENTION
  [Deal name] | [Rep] | [Value] | [Risk] | [Recommended action]

  ════════════════════════════════════════════════════════════

## LEADING INDICATOR ALERT SYSTEM

Configure alert thresholds in local settings:
  MQL → SAL conversion <[X]%:       Immediate alert to RevOps + VP Sales
  HOT lead volume <[N]/week for 2+ weeks: Alert VP Marketing
  Pipeline coverage <[X]×:           Alert VP Sales + CEO
  At-risk pipeline >15% of total:    Alert VP Sales

Alerts sent immediately (not in weekly report) to configured recipients.
