---
name: marketing-performance-agent
version: 1.0
description: >
  Activate for: weekly marketing report, marketing performance, automated
  report, channel performance report, campaign dashboard, Friday report,
  marketing analytics, ROI report, lead quality report, automated analysis,
  pull campaign data, performance summary.
mcp-integrations: LinkedIn Campaign Manager, Google Analytics GA4,
                  Email platform (HubSpot/Mailchimp/Klaviyo),
                  CRM, Google Ads, Meta Ads (if applicable)
---

## AGENT PURPOSE

Automatically pull weekly performance data from all connected marketing channels.
Generate analysis report with top 3 optimisation recommendations.
Distribute to relevant stakeholders. Track progress against campaign KPIs.

## AUTOMATED SCHEDULE

Every Friday (or configured day):
1. Pull data from all connected channels via MCP (preceding 7 days)
2. Compare actuals to targets (from campaign brief in local config)
3. Compare actuals to prior week (trend)
4. Run /analyze workflow → top 3 optimisation opportunities
5. Generate weekly performance report
6. Distribute: Marketing team (full report) / Leadership (summary only)

## DATA PULL SPECIFICATION

From LinkedIn Campaign Manager:
  - Impressions, clicks, CTR by campaign and ad variant
  - Cost per click (CPC), cost per lead (CPL)
  - Lead gen form completions (if used)
  - Audience reach and frequency

From Google Analytics / GA4:
  - Sessions by source/medium
  - Landing page conversion rates
  - Content downloads (goal completions)
  - Page engagement (time on page, scroll depth)

From Email Platform:
  - Send volume, delivery rate, open rate, click rate by campaign
  - Unsubscribe rate (flag if >0.5%)
  - Best and worst performing subject lines
  - Best and worst performing CTAs

From CRM:
  - Leads created by source this week
  - Lead score distribution by source
  - HOT leads by source
  - MQL → SAL conversion this week
  - Pipeline created from marketing leads

## DISTRIBUTION LIST (configure in local settings)

Full report:    [Marketing team email]
Summary only:   [VP Marketing, VP Sales, CEO — as configured]
Anomaly alerts: [RevOps lead — immediate if threshold breached]

## ANOMALY ALERT TRIGGERS (send immediately, not in weekly report)

Alert immediately if:
  - Email unsubscribe rate >0.5% in any single send
  - Ad spend depleted before end of scheduled period
  - Landing page conversion drops >30% week-over-week
  - HOT lead volume drops >25% week-over-week with no explained cause
  - CRM integration error: leads not flowing from marketing to sales
